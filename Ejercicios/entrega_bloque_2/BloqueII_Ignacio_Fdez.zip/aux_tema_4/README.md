# Crear árboles de decisión
```
python arbol.py arbol_ej_4.json
```
